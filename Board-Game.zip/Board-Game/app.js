(function(){

  var lives = 3;
  var timeLimitInMinutes = 5;
  var fillBoxes = 5;

  this.view = new app.View();
  this.modal = new app.Modal(lives,timeLimitInMinutes);
  this.control = new app.Control(this.view, this.modal, fillBoxes);

  document.getElementById('startStop').addEventListener('click',function(){
    
  modal.gameStatus === 'Stop' && control.startGame();
  
})

})();