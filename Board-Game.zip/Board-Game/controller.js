(function(window){
    
    
      function Control(view,modal,fillBoxes){
        this.view =view;
        this.modal = modal;
        var matrix = [];
        
        while(matrix.length < fillBoxes){
            var randomnumber = Math.floor(Math.random()*5) ;
            var randomnumber1 = Math.floor(Math.random()*5) ;
            var str = ''+randomnumber+randomnumber1;
            if(matrix.indexOf(matrix) > -1) continue;
            matrix[matrix.length] = str;
        }
        this.arr = matrix;
        this.view.render(this.modal.lives,this.modal.timeLimit,matrix);
      
      }

   
      Control.prototype.startGame = function(){
        this.startInterval();
        this.view.startEvent(this.gameAction);
         
      }
       

      Control.prototype.gameAction = function(e){
         e.target.id === 'miniBlock' ? (e.target.className === 'red' ? 
                                          e.target.className = 'white': 
                                          e.target.className = 'red')
                                       : null;   

         if(!this.view.getRedBlocks().length) {
            this.view.status('Won')
        }                               
        
         
      }

      

      Control.prototype.startInterval = function(limit){
        this.modal.setGameStatus('Progress');
        var interval = window.setInterval(function(){
            var i = document.getElementById('timeLeft').innerText.split(':');
            if(i[0] == 0 && i[1] == 1 ) {
                clearInterval(interval);
                if(this.view.getRedBlocks().length)   
                {
                    if(this.modal.lives){
                        this.modal.decrementLife();
                        this.view.rerender(this.modal.lives,this.modal.timeLimit,this.arr);
                        this.modal.setGameStatus('Stop');
                    }
                    else {
                        this.view.status('lose');
                        this.modal.setGameStatus('Stop');
                    }
                }

                else {
                   this.view.status('won');
                   this.modal.setGameStatus('Stop');
                }
            
            }
            else {
            var totalSeconds = parseInt(i[0])*60 + parseInt(i[1])-1;
            var minutes = Math.floor(totalSeconds / 60);
            var seconds = totalSeconds - minutes*60;
            
            document.getElementById('timeLeft').innerText = minutes + ':' + seconds;
            }
           },1000)
      }

       
    
      window.app = window.app || {};
      window.app.Control = Control;
    })(window);