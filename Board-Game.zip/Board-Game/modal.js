(function(window){
    
    
      function Modal(lives,timeLimit){
          this.lives = lives;
          this.timeLimit = timeLimit;
          this.gameStatus = 'Stop';
       
      }

      Modal.prototype.decrementLife = function(){
        this.lives = this.lives -1;
      }


     Modal.prototype.setGameStatus = function(value){
        this.gameStatus = value;
      }
      


       
    
      window.app = window.app || {};
      window.app.Modal = Modal;
    })(window);