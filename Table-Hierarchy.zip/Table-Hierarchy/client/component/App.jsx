import React from 'react';
import Row from './Row.jsx';
import data from '../../data.js';

class App extends React.Component {
    render(){
      return(
        <table>
            <tbody>
             <tr>
                 <td></td>
                 <td>Id</td>
                 <td>Emp Name</td>
                 <td>Designation</td>
            </tr>
            {
                data.map(d=><Row data={d}/>)
            }
            </tbody>
            

        </table>


    )}

}

export default App;