import React from 'react';





class Row extends React.Component {

  constructor(){
      super();
      this.state = {childVisible: false};  
      this.showChild = this.showChild.bind(this);
    
    } 

  
 showChild(){
   this.setState({childVisible:!this.state.childVisible});
 }
   

    render(){
       const {id,name,designation,children} = this.props.data;
       const childPresent = children && children.length;
      return(
        <React.Fragment>
        <tr>
          <td onClick={ childPresent && this.showChild}>

          {childPresent && (this.state.childVisible ? '-' : '+')}
          
          </td>
          <td>{id}</td>
          <td>{name}</td>
          <td>{designation}</td>
        </tr>
        {this.state.childVisible && childPresent && 
          
          children.map(item =><Row data={item}/>)}
      </React.Fragment>
      
      )
      }


    

}

export default Row;