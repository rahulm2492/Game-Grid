const data = [

    {
      
        id:1,
        name:'Manoj',
        designation:'Manager',
        children:[{
            id:1,
            name:'Atul',
            designation:'Engineer',
            children:[
                        {
                            id:2,
                            name:'Abhishek',
                            designation:'Engineer'
                        
                        
                        }
                    ]

    },
    
    {id:1,
            name:'Rahul',
            designation:'Engineer',
            children:[
                        {
                            id:2,
                            name:'Abhis',
                            designation:'Engineer'
                        
                        
                        }
                    ]

    }
    ]
    },
    {
        
          id:1,
          name:'Ruchi',
          designation:'Manager',
          children:[{
              id:1,
              name:'Shivangi',
              designation:'Engineer',
              children:[
                          {
                              id:1,
                              name:'Deepak',
                              designation:'Engineer'
                          
                          
                          }
                      ]
  
      }]
      }
];

    export default data;